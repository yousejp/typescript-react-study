import React from 'react';

const App = () => {
  return <div>React Starter Kit in TypeScript</div>;
};

export default App;
